package hu.ait.spotifydemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.google.gson.Gson
import hu.ait.spotifydemo.data.AudioFeatures
import hu.ait.spotifydemo.data.Base
import hu.ait.spotifydemo.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        Log.d("CREATED", "PROJECT CREATED")
        binding.btnSearch.setOnClickListener {
            var retrofit = Retrofit.Builder()
                .baseUrl("https://api.spotify.com/v1/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()


            var spotifyAPI = retrofit.create(SpotifyAPI::class.java)

            val call = spotifyAPI.getTrackFeatures("1tzPSule9WZ9B8SujHv8fp")
            Log.d("HIT", "${call}")
            call.enqueue(object : Callback<AudioFeatures>{

                override fun onResponse(call: Call<AudioFeatures>, response: Response<AudioFeatures>) {
                    var spotifyResult = response.body()
                    Log.d("HIT2", "The response is"+"${spotifyResult?.acousticness}")
                    binding.tvDemo.text = "${spotifyResult?.acousticness}"
                }

                override fun onFailure(call: Call<AudioFeatures>, t: Throwable) {
                    TODO("Not yet implemented")
                    

                }

            })
        }

    }





}