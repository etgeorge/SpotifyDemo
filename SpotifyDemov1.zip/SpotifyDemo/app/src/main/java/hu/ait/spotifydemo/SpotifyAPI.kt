package hu.ait.spotifydemo

import hu.ait.spotifydemo.data.AudioFeatures
import hu.ait.spotifydemo.data.Base
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query


interface SpotifyAPI {
    @GET("audio-features")
    fun getTrackFeatures(@Query("id") id: String): Call<AudioFeatures>
}